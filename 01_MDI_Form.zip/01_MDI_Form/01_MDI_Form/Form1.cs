﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _01_MDI_Form
{
    public partial class MDIForm : Form
    {
        public MDIForm()
        {
            InitializeComponent();
        }

        private void MDIForm_Load(object sender, EventArgs e)
        {

        }

        

        private void tipoDeLetraToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            /* como ya validé que no se repita la instancia por cada click que de
             * entonces cambio la línea y llamo al método ValidaInstancia   */
            //Frm_TipoLetra frm_TLetra = new Frm_TipoLetra();

            // creando un objeto de la clase pero llamando directamente a un método
            Frm_TipoLetra frm_TLetra = Frm_TipoLetra.UnaVentana();

            frm_TLetra.MdiParent = this;  // ejecuta Frm_TipoLetra dentro del MDI
            frm_TLetra.Show();
        }
    }
}
